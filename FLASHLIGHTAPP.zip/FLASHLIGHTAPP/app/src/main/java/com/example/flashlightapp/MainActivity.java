package com.example.flashlightapp;

import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private CameraManager cameraManager;
    private String cameraId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Check if the device has a camera flash
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)) {
            // Handle the case where the device doesn't have a camera flash
            Toast.makeText(this, "Flashlight not available on this device.", Toast.LENGTH_SHORT).show();
            ToggleButton toggleButton = findViewById(R.id.toggleButton);
            toggleButton.setEnabled(false);
            return;
        }

        // Initialize the camera manager
        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }

        // Set the toggle button listener
        ToggleButton toggleButton = findViewById(R.id.toggleButton);
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    turnOnFlashlight();
                } else {
                    turnOffFlashlight();
                }
            }
        });
    }

    private void turnOnFlashlight() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, true);
            }
        } catch (CameraAccessException e) {
            // Handle the case where the flashlight fails to turn on
            e.printStackTrace();
            Toast.makeText(this, "Failed to turn on flashlight.", Toast.LENGTH_SHORT).show();
            ToggleButton toggleButton = findViewById(R.id.toggleButton);
            toggleButton.setChecked(false);
        }
    }

    private void turnOffFlashlight() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, false);
            }
        } catch (CameraAccessException e) {
            // Handle the case where the flashlight fails to turn off
            e.printStackTrace();
            Toast.makeText(this, "Failed to turn off flashlight.", Toast.LENGTH_SHORT).show();
            ToggleButton toggleButton = findViewById(R.id.toggleButton);
            toggleButton.setChecked(true);
        }
    }
}

